package cash.movix.app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.Window;
import android.webkit.ConsoleMessage;
import android.webkit.CookieManager;
import android.webkit.SslErrorHandler;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.net.http.SslError;
import android.widget.FrameLayout;

import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends Activity {
    private static final String DEFAULT_URL = "https://movix.cash";
    private static final int RED = Color.rgb(217, 70, 70);
    private static final int SCREEN_LOADING = 0;
    private static final int SCREEN_ERROR = 1;
    private static final int SCREEN_SETTINGS = 2;
    private static final int SCREEN_CONTENT = 3;

    private WebView splashView;
    private WebView contentView;
    private FrameLayout root;
    private final Handler handler = new Handler();

    private boolean loading = false;
    private boolean splashReady = false;
    private boolean blankCheckScheduled = false;
    private int attempt = 0;
    private int lastProgress = 0;
    private int currentScreen = SCREEN_LOADING;
    private String lastLoadedUrl = DEFAULT_URL;
    private PreflightTask testTask;

    private final Runnable timeoutRunnable = new Runnable() {
        @Override public void run() {
            if (loading) finishWithError("slow");
        }
    };

    private final Runnable blankCheckRunnable = new Runnable() {
        @Override public void run() {
            if (!loading) return;
            blankCheckScheduled = false;
            checkPageIsVisible();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setStatusBarColor(RED);
        getWindow().setNavigationBarColor(Color.BLACK);

        root = new FrameLayout(this);
        contentView = createWebView();
        splashView = createWebView();

        root.addView(contentView, new FrameLayout.LayoutParams(-1, -1));
        root.addView(splashView, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);

        setupContentWebView();
        setupSplashWebView();
        splashView.loadUrl("file:///android_asset/www/index.html");
    }

    private WebView createWebView() {
        WebView w = new WebView(this);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setSupportZoom(false);
        s.setLoadsImagesAutomatically(true);
        s.setBlockNetworkImage(false);
        s.setBlockNetworkLoads(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setUserAgentString("Mozilla/5.0 (Linux; Android 5.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Mobile Safari/537.36");
        if (Build.VERSION.SDK_INT >= 21) {
            s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
            CookieManager.getInstance().setAcceptThirdPartyCookies(w, true);
        }
        if (Build.VERSION.SDK_INT == 21 || Build.VERSION.SDK_INT == 22) {
            w.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        }
        return w;
    }

    private void setupSplashWebView() {
        splashView.addJavascriptInterface(new NativeBridge(), "MovixNative");
        splashView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                if (splashReady) return;
                splashReady = true;
                getConfiguredUrl(new UrlCallback() {
                    @Override public void onUrl(String url) {
                        startLoad(url);
                    }
                });
            }
        });
        splashView.setWebChromeClient(new WebChromeClient());
    }

    private void setupContentWebView() {
        contentView.setVisibility(View.INVISIBLE);
        contentView.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view, int newProgress) {
                lastProgress = newProgress;
                if (!loading) return;
                int p = Math.max(5, Math.min(96, newProgress));
                String text = newProgress < 25 ? "Connexion au serveur…" : "Chargement de Movix…";
                updateSplashProgress(p, text);
            }

            @Override public boolean onConsoleMessage(ConsoleMessage consoleMessage) {
                return true;
            }
        });

        contentView.setWebViewClient(new WebViewClient() {
            // Normal HTTP(S) redirects and navigation stay inside the app.
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url == null) return false;
                if (url.startsWith("http://") || url.startsWith("https://")) return false;
                openExternalUrl(url);
                return true;
            }

            // Same behavior for the newer Android 5+ callback.
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                if (request == null || request.getUrl() == null) return false;
                String url = request.getUrl().toString();
                if (url.startsWith("http://") || url.startsWith("https://")) return false;
                openExternalUrl(url);
                return true;
            }

            @Override public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                if (loading) {
                    updateSplashProgress(Math.max(5, lastProgress), "Connexion au serveur…");
                }
            }

            @Override public void onPageFinished(WebView view, String url) {
                if (!loading) return;
                lastLoadedUrl = url == null ? lastLoadedUrl : url;
                handler.removeCallbacks(blankCheckRunnable);
                blankCheckScheduled = true;
                handler.postDelayed(blankCheckRunnable, 1400);
            }

            @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (Build.VERSION.SDK_INT >= 21 && request != null && request.isForMainFrame() && loading) {
                    finishWithError("server");
                }
            }

            @Override public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                if (loading) finishWithError("server");
            }

            @Override public void onReceivedHttpError(WebView view, WebResourceRequest request, WebResourceResponse errorResponse) {
                if (Build.VERSION.SDK_INT >= 21 && request != null && request.isForMainFrame() && loading) {
                    int code = errorResponse == null ? 0 : errorResponse.getStatusCode();
                    if (code >= 400) finishWithError("server");
                }
            }

            @Override public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                handler.cancel();
                if (loading) finishWithError("ssl");
            }
        });
    }

    private void openExternalUrl(String url) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (Exception ignored) { }
    }

    private boolean hasInternet() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo ni = cm.getActiveNetworkInfo();
        return ni != null && ni.isConnected();
    }

    private void getConfiguredUrl(final UrlCallback callback) {
        try {
            String js = "window.movixApp&&window.movixApp.getUrl?window.movixApp.getUrl():''";
            splashView.evaluateJavascript(js, new ValueCallback<String>() {
                @Override public void onReceiveValue(String value) {
                    String clean = decodeJsString(value);
                    if (clean.length() == 0) clean = DEFAULT_URL;
                    callback.onUrl(clean);
                }
            });
        } catch (Exception e) {
            callback.onUrl(DEFAULT_URL);
        }
    }

    private String decodeJsString(String value) {
        String clean = value == null ? "" : value;
        if (clean.startsWith("\"") && clean.endsWith("\"")) {
            clean = clean.substring(1, clean.length() - 1);
        }
        return clean.replace("\\u0022", "\"").replace("\\/", "/").replace("\\\\", "\\");
    }

    private void updateSplashProgress(final int value, final String text) {
        if (splashView == null) return;
        splashView.post(new Runnable() {
            @Override public void run() {
                String safe = text.replace("\\", "\\\\").replace("'", "\\'");
                String js = "window.movixApp&&window.movixApp.setProgress(" + value + ", '" + safe + "')";
                if (Build.VERSION.SDK_INT >= 19) splashView.evaluateJavascript(js, null);
                else splashView.loadUrl("javascript:" + js);
            }
        });
    }

    private void showSplashError(final String type) {
        loading = false;
        currentScreen = SCREEN_ERROR;
        splashView.setVisibility(View.VISIBLE);
        contentView.setVisibility(View.INVISIBLE);
        splashView.post(new Runnable() {
            @Override public void run() {
                String js = "window.movixApp&&window.movixApp.showError('" + type + "')";
                if (Build.VERSION.SDK_INT >= 19) splashView.evaluateJavascript(js, null);
                else splashView.loadUrl("javascript:" + js);
            }
        });
    }

    private void finishWithError(String type) {
        if (!loading) return;
        loading = false;
        handler.removeCallbacks(timeoutRunnable);
        handler.removeCallbacks(blankCheckRunnable);
        blankCheckScheduled = false;
        showSplashError(type);
    }

    private void resetContentWebView() {
        try {
            if (contentView != null) {
                contentView.stopLoading();
                contentView.setVisibility(View.GONE);
                root.removeView(contentView);
                contentView.destroy();
            }
        } catch (Exception ignored) { }
        contentView = createWebView();
        root.addView(contentView, 0, new FrameLayout.LayoutParams(-1, -1));
        setupContentWebView();
    }

    private void resetSplashForAttempt() {
        loading = false;
        currentScreen = SCREEN_LOADING;
        lastProgress = 0;
        handler.removeCallbacks(timeoutRunnable);
        handler.removeCallbacks(blankCheckRunnable);
        blankCheckScheduled = false;
        splashView.setVisibility(View.VISIBLE);
        contentView.setVisibility(View.INVISIBLE);
        updateSplashProgress(0, "Vérification de la connexion…");
    }

    private void startLoad(final String url) {
        if (url == null || !(url.startsWith("http://") || url.startsWith("https://"))) {
            showSplashError("badurl");
            return;
        }
        resetSplashForAttempt();
        if (!hasInternet()) {
            updateSplashProgress(0, "Aucune connexion Internet");
            handler.postDelayed(new Runnable() {
                @Override public void run() { if (!loading) showSplashError("offline"); }
            }, 450);
            return;
        }

        attempt++;
        loading = true;
        currentScreen = SCREEN_LOADING;
        lastLoadedUrl = url;
        resetContentWebView();
        final int thisAttempt = attempt;
        updateSplashProgress(5, "Connexion au serveur…");
        handler.postDelayed(new Runnable() {
            @Override public void run() {
                if (loading && thisAttempt == attempt) finishWithError("slow");
            }
        }, 15000);

        try {
            contentView.loadUrl(url);
        } catch (Exception e) {
            finishWithError("server");
        }
    }

    private void retryLoad() {
        if (currentScreen != SCREEN_ERROR && currentScreen != SCREEN_LOADING) return;
        getConfiguredUrl(new UrlCallback() {
            @Override public void onUrl(String url) {
                // A completely fresh WebView is used for every retry, avoiding the crash
                // caused by reloading a stale WebView state on old Android versions.
                startLoad(url);
            }
        });
    }

    private void checkPageIsVisible() {
        if (!loading) return;
        try {
            contentView.evaluateJavascript(
                "(function(){var b=document.body,d=document.documentElement;var html=d?(d.innerHTML||'').trim():'';var children=b?b.children.length:0;var text=b?((b.innerText||'').trim()):'';var title=document.title||'';return JSON.stringify({html:html.length,children:children,text:text.length,title:title});})()",
                new ValueCallback<String>() {
                    @Override public void onReceiveValue(String value) {
                        if (!loading) return;
                        boolean empty = value == null || value.equals("null") || value.length() < 10 || value.contains("\"html\":0") || value.contains("\"children\":0");
                        if (empty) {
                            // Give slow JavaScript applications one extra chance before
                            // declaring a white/incompatible page.
                            handler.postDelayed(new Runnable() {
                                @Override public void run() {
                                    if (loading) checkPageIsVisibleSecondPass();
                                }
                            }, 1800);
                            return;
                        }
                        showContent();
                    }
                });
        } catch (Exception e) {
            finishWithError("compat");
        }
    }

    private void checkPageIsVisibleSecondPass() {
        if (!loading) return;
        try {
            contentView.evaluateJavascript("(function(){var d=document.documentElement,b=document.body;return (d&&d.innerHTML?d.innerHTML.length:0)+'|'+(b?b.children.length:0);})()", new ValueCallback<String>() {
                @Override public void onReceiveValue(String value) {
                    if (!loading) return;
                    if (value == null || value.contains("|0") || value.equals("0|0")) finishWithError("compat");
                    else showContent();
                }
            });
        } catch (Exception e) {
            finishWithError("compat");
        }
    }

    private void showContent() {
        if (!loading) return;
        loading = false;
        currentScreen = SCREEN_CONTENT;
        handler.removeCallbacks(timeoutRunnable);
        handler.removeCallbacks(blankCheckRunnable);
        updateSplashProgress(100, "Chargement terminé");
        contentView.setVisibility(View.VISIBLE);
        splashView.setVisibility(View.GONE);
    }

    private class PreflightTask extends AsyncTask<String, Void, Boolean> {
        private final String target;
        PreflightTask(String target) { this.target = target; }
        @Override protected Boolean doInBackground(String... ignored) {
            HttpURLConnection c = null;
            try {
                URL u = new URL(target);
                c = (HttpURLConnection) u.openConnection();
                c.setConnectTimeout(3500);
                c.setReadTimeout(3500);
                c.setInstanceFollowRedirects(true);
                c.setRequestMethod("GET");
                c.setRequestProperty("Range", "bytes=0-0");
                c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 5.0) AppleWebKit/537.36 Chrome/80 Mobile Safari/537.36");
                int code = c.getResponseCode();
                return code >= 200 && code < 500;
            } catch (Exception e) {
                return false;
            } finally {
                if (c != null) c.disconnect();
            }
        }
        @Override protected void onPostExecute(final Boolean ok) {
            if (isFinishing()) return;
            splashView.post(new Runnable() {
                @Override public void run() {
                    String js = "window.movixApp&&window.movixApp.testResult(" + ok + ")";
                    if (Build.VERSION.SDK_INT >= 19) splashView.evaluateJavascript(js, null);
                    else splashView.loadUrl("javascript:" + js);
                }
            });
        }
    }

    private interface UrlCallback { void onUrl(String url); }

    public class NativeBridge {
        @android.webkit.JavascriptInterface
        public void retryLoad() {
            runOnUiThread(new Runnable() { @Override public void run() { retryLoad(); } });
        }
        @android.webkit.JavascriptInterface
        public void startLoad(final String url) {
            runOnUiThread(new Runnable() { @Override public void run() { startLoad(url); } });
        }
        @android.webkit.JavascriptInterface
        public void screenChanged(final String screen) {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    if ("settings".equals(screen)) currentScreen = SCREEN_SETTINGS;
                    else if ("error".equals(screen)) currentScreen = SCREEN_ERROR;
                    else if ("loading".equals(screen)) currentScreen = SCREEN_LOADING;
                    else if ("content".equals(screen)) currentScreen = SCREEN_CONTENT;
                }
            });
        }

        @android.webkit.JavascriptInterface
        public void networkLost() {
            runOnUiThread(new Runnable() { @Override public void run() { if (loading) finishWithError("offline"); } });
        }
        @android.webkit.JavascriptInterface
        public void testUrl(final String url) {
            if (testTask != null) testTask.cancel(true);
            if (url == null || !(url.startsWith("http://") || url.startsWith("https://"))) {
                splashView.post(new Runnable() { @Override public void run() { splashView.evaluateJavascript("window.movixApp&&window.movixApp.testResult(false)", null); } });
                return;
            }
            testTask = new PreflightTask(url);
            testTask.execute(url);
        }
    }

    @Override public void onBackPressed() {
        if (currentScreen == SCREEN_SETTINGS) {
            splashView.evaluateJavascript("window.movixApp&&window.movixApp.closeSettings&&window.movixApp.closeSettings()", null);
            return;
        }
        if (currentScreen == SCREEN_ERROR) {
            splashView.evaluateJavascript("window.movixApp&&window.movixApp.goBack&&window.movixApp.goBack()", null);
            return;
        }
        if (currentScreen == SCREEN_LOADING) {
            // Keep the startup screen visible instead of unexpectedly exiting.
            return;
        }
        if (contentView != null && contentView.canGoBack()) contentView.goBack();
        else super.onBackPressed();
    }

    // Called by the splash page through the JS bridge when settings are opened/closed.
    public void setScreenFromJs(int screen) { currentScreen = screen; }

    @Override protected void onDestroy() {
        loading = false;
        handler.removeCallbacks(timeoutRunnable);
        handler.removeCallbacks(blankCheckRunnable);
        if (testTask != null) testTask.cancel(true);
        try { if (splashView != null) splashView.destroy(); } catch (Exception ignored) { }
        try { if (contentView != null) contentView.destroy(); } catch (Exception ignored) { }
        super.onDestroy();
    }
}
