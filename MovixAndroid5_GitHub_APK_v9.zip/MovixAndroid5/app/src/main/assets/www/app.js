(function(){
  var DEFAULT_URL = "https://movix.cash";
  var url = localStorage.getItem("movix_url") || DEFAULT_URL;
  var splash = document.getElementById("splash");
  var settings = document.getElementById("settings");
  var error = document.getElementById("error");
  var percent = document.getElementById("percent");
  var progress = document.getElementById("progress");
  var status = document.getElementById("status");
  var urlInput = document.getElementById("urlInput");
  var urlMessage = document.getElementById("urlMessage");
  var settingsOrigin = "splash";

  urlInput.value = url;

  function show(el){el.classList.remove("hidden");}
  function hide(el){el.classList.add("hidden");}
  function setProgress(n,text){
    n=Math.max(0,Math.min(100,n|0));
    percent.textContent=n+" %";
    progress.style.width=n+"%";
    if(text) status.textContent=text;
  }
  function validUrl(value){return /^https?:\/\/[^\s]+$/i.test(value);}

  function tellNativeScreen(name){
    if(!window.MovixNative) return;
    // Screen state is primarily kept here in JS; Java also tracks it when needed.
    if(window.MovixNative.screenChanged) window.MovixNative.screenChanged(name);
  }

  function openSettings(){
    settingsOrigin = !error.classList.contains("hidden") ? "error" : "splash";
    urlInput.value=localStorage.getItem("movix_url")||DEFAULT_URL;
    urlMessage.textContent="";
    hide(splash); hide(error); show(settings);
    tellNativeScreen("settings");
    try{urlInput.focus();}catch(e){}
  }

  function closeSettings(){
    hide(settings);
    if(settingsOrigin==="error"){
      show(error);
      tellNativeScreen("error");
    }else{
      show(splash);
      tellNativeScreen("loading");
    }
  }

  function goBack(){closeSettings();}

  function showError(type){
    hide(splash); hide(settings); show(error);
    var title=document.getElementById("errorTitle");
    var text=document.getElementById("errorText");
    var advice=document.getElementById("errorAdvice");
    if(type==="offline"){
      title.textContent="Aucune connexion Internet";
      text.textContent="Le téléphone ne semble pas avoir accès à Internet.";
      advice.textContent="Vérifiez le Wi‑Fi ou les données mobiles, puis appuyez sur « Réessayer ».";
    }else if(type==="slow"){
      title.textContent="Connexion trop lente";
      text.textContent="Le serveur met trop de temps à répondre.";
      advice.textContent="Vérifiez votre connexion puis réessayez. Vous pouvez aussi vérifier l'adresse avec le bouton URL.";
    }else if(type==="badurl"){
      title.textContent="Adresse incorrecte";
      text.textContent="L'adresse configurée n'est pas valide.";
      advice.textContent="L'adresse doit commencer par http:// ou https://.";
    }else if(type==="ssl"){
      title.textContent="Connexion sécurisée impossible";
      text.textContent="Le certificat du serveur n'a pas pu être vérifié.";
      advice.textContent="Réessayez plus tard ou vérifiez l'adresse avec le bouton URL.";
    }else if(type==="compat"){
      title.textContent="Affichage incompatible";
      text.textContent="Cette version d'Android n'arrive pas à afficher correctement la page.";
      advice.textContent="Appuyez sur « Réessayer » pour refaire un test complet depuis le début.";
    }else{
      title.textContent="Movix est inaccessible";
      text.textContent="Internet fonctionne, mais la page n'a pas pu être chargée correctement.";
      advice.textContent="Appuyez sur « Réessayer » pour refaire un test complet depuis le début.";
    }
    tellNativeScreen("error");
  }

  document.getElementById("urlBtn").onclick=openSettings;
  document.getElementById("diagnosticBtn").onclick=function(){
    if(window.MovixNative&&window.MovixNative.openDiagnostic) window.MovixNative.openDiagnostic();
  };
  document.getElementById("errorUrlBtn").onclick=openSettings;
  document.getElementById("backBtn").onclick=closeSettings;

  document.getElementById("retryBtn").onclick=function(){
    // Immediately reset the visual state. Java then creates a brand-new WebView.
    hide(error); show(splash);
    setProgress(0,"Vérification de la connexion…");
    tellNativeScreen("loading");
    if(window.MovixNative&&window.MovixNative.retryLoad) window.MovixNative.retryLoad();
  };

  document.getElementById("saveBtn").onclick=function(){
    var value=urlInput.value.trim().replace(/\/+$/," ").trim();
    if(!validUrl(value)){
      urlMessage.textContent="Adresse invalide. Exemple : https://movix.cash";
      return;
    }
    localStorage.setItem("movix_url",value);
    url=value;
    // A saved URL is an explicit request to test the new address, so start fresh.
    hide(settings); show(splash); setProgress(0,"Vérification de la connexion…"); tellNativeScreen("loading");
    if(window.MovixNative&&window.MovixNative.startLoad) window.MovixNative.startLoad(value);
  };

  document.getElementById("testBtn").onclick=function(){
    var value=urlInput.value.trim().replace(/\/+$/," ").trim();
    if(!validUrl(value)){urlMessage.textContent="Adresse invalide.";return;}
    urlMessage.textContent="Test en cours…";
    if(window.MovixNative&&window.MovixNative.testUrl) window.MovixNative.testUrl(value);
  };

  window.movixApp={
    setProgress:setProgress,
    showError:showError,
    getUrl:function(){return localStorage.getItem("movix_url")||DEFAULT_URL;},
    closeSettings:closeSettings,
    goBack:goBack,
    testResult:function(ok){urlMessage.textContent=ok?"Serveur joignable.":"Impossible de joindre cette adresse.";}
  };

  window.addEventListener("offline",function(){
    if(window.MovixNative&&window.MovixNative.networkLost) window.MovixNative.networkLost();
  });
})();
