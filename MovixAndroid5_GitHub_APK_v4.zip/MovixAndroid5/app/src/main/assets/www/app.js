(function(){
  var DEFAULT_URL = "https://movix.cash";
  var url = localStorage.getItem("movix_url") || DEFAULT_URL;
  var splash = document.getElementById("splash");
  var settings = document.getElementById("settings");
  var error = document.getElementById("error");
  var percent = document.getElementById("percent");
  var progress = document.getElementById("progress");
  var status = document.getElementById("status");
  var urlInput = document.getElementById("urlInput");
  var urlMessage = document.getElementById("urlMessage");

  urlInput.value = url;

  function show(el){el.classList.remove("hidden")}
  function hide(el){el.classList.add("hidden")}
  function setProgress(n, text){
    n = Math.max(0, Math.min(100, n|0));
    percent.textContent = n + " %";
    progress.style.width = n + "%";
    if(text) status.textContent = text;
  }
  function validUrl(value){ return /^https?:\/\/[^\s]+$/i.test(value); }

  function openSettings(){
    urlInput.value = localStorage.getItem("movix_url") || DEFAULT_URL;
    urlMessage.textContent = "";
    hide(splash); hide(error); show(settings);
  }
  function closeSettings(){ hide(settings); show(splash); }
  function goBack(){
    if(!settings.classList.contains("hidden") || !error.classList.contains("hidden")){
      hide(settings); hide(error); show(splash); return;
    }
    show(splash);
  }
  function showError(type){
    hide(splash); hide(settings); show(error);
    var title=document.getElementById("errorTitle");
    var text=document.getElementById("errorText");
    var advice=document.getElementById("errorAdvice");
    if(type==="offline"){
      title.textContent="Aucune connexion Internet";
      text.textContent="Le téléphone ne semble pas avoir accès à Internet.";
      advice.textContent="Vérifiez le Wi‑Fi ou les données mobiles, puis appuyez sur « Réessayer ».";
    } else if(type==="slow"){
      title.textContent="Connexion trop lente";
      text.textContent="Le serveur met trop de temps à répondre.";
      advice.textContent="Vérifiez votre connexion puis réessayez. Vous pouvez aussi vérifier l'adresse dans les paramètres.";
    } else if(type==="badurl"){
      title.textContent="Adresse incorrecte";
      text.textContent="L'adresse configurée n'est pas valide.";
      advice.textContent="L'adresse doit commencer par http:// ou https://.";
    } else if(type==="ssl"){
      title.textContent="Connexion sécurisée impossible";
      text.textContent="Le certificat du serveur n'a pas pu être vérifié.";
      advice.textContent="Réessayez plus tard ou vérifiez l'adresse configurée.";
    } else if(type==="compat"){
      title.textContent="Affichage incompatible";
      text.textContent="Cette version d'Android n'arrive pas à afficher correctement la page Movix.";
      advice.textContent="Essayez une autre adresse Movix dans les paramètres, ou réessayez plus tard.";
    } else {
      title.textContent="Movix est inaccessible";
      text.textContent="Internet fonctionne, mais la page Movix n'a pas pu être chargée correctement.";
      advice.textContent="Réessayez dans quelques instants ou vérifiez l'adresse du serveur dans les paramètres.";
    }
  }

  document.getElementById("settingsBtn").onclick=openSettings;
  document.getElementById("backBtn").onclick=closeSettings;
  document.getElementById("errorSettingsBtn").onclick=openSettings;
  document.getElementById("retryBtn").onclick=function(){ hide(error); show(splash); start(); };

  document.getElementById("saveBtn").onclick=function(){
    var value=urlInput.value.trim().replace(/\/+$/," ").trim();
    if(!validUrl(value)){
      urlMessage.textContent="Adresse invalide. Exemple : https://movix.cash";
      return;
    }
    localStorage.setItem("movix_url",value);
    url=value;
    urlMessage.textContent="Adresse enregistrée.";
    setTimeout(function(){ hide(settings); show(splash); start(); },250);
  };

  document.getElementById("testBtn").onclick=function(){
    var value=urlInput.value.trim().replace(/\/+$/," ").trim();
    if(!validUrl(value)){urlMessage.textContent="Adresse invalide.";return;}
    urlMessage.textContent="Test en cours…";
    if(window.MovixNative && window.MovixNative.testUrl){
      window.MovixNative.testUrl(value);
    } else {
      urlMessage.textContent="Test disponible dans l'application.";
    }
  };

  window.movixApp={
    setProgress:setProgress,
    showError:showError,
    getUrl:function(){return localStorage.getItem("movix_url")||DEFAULT_URL},
    closeSettings:closeSettings,
    goBack:goBack,
    testResult:function(ok){ urlMessage.textContent=ok?"Serveur joignable.":"Impossible de joindre cette adresse."; }
  };

  function start(){
    url=localStorage.getItem("movix_url")||DEFAULT_URL;
    setProgress(0,"Vérification de la connexion…");
    if(!navigator.onLine){showError("offline");return}
    setProgress(5,"Vérification de la connexion…");
    if(window.MovixNative && window.MovixNative.startLoad){
      window.MovixNative.startLoad(url);
    } else {
      setProgress(100,"Chargement terminé");
      window.location.href=url;
    }
  }

  window.addEventListener("online",function(){ if(!settings.classList.contains("hidden"))return; start(); });
  window.addEventListener("offline",function(){ showError("offline"); });
})();
