package cash.movix.app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Looper;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.URL;
import java.util.Locale;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.Window;
import android.webkit.ConsoleMessage;
import android.webkit.CookieManager;
import android.webkit.SslErrorHandler;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.net.http.SslError;
import android.widget.FrameLayout;

public class MainActivity extends Activity {
    private static final String DEFAULT_URL = "https://movix.cash";
    private static final int RED = Color.rgb(217, 70, 70);
    private static final int SCREEN_LOADING = 0;
    private static final int SCREEN_ERROR = 1;
    private static final int SCREEN_SETTINGS = 2;
    private static final int SCREEN_CONTENT = 3;

    private WebView splashView;
    private WebView contentView;
    private FrameLayout root;
    private final Handler handler = new Handler();
    private boolean loading = false;
    private boolean splashReady = false;
    private int attempt = 0;
    private long loadGeneration = 0L;
    private int currentScreen = SCREEN_LOADING;
    private String lastLoadedUrl = DEFAULT_URL;
    private boolean diagnosticMode = false;
    private String webViewUserAgent = "inconnu";

    private final Runnable timeoutRunnable = new Runnable() {
        @Override public void run() {
            if (loading) finishWithError("slow");
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setStatusBarColor(RED);
        getWindow().setNavigationBarColor(Color.BLACK);

        root = new FrameLayout(this);
        contentView = createWebView();
        splashView = createWebView();
        root.addView(contentView, new FrameLayout.LayoutParams(-1, -1));
        root.addView(splashView, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);

        setupContentWebView();
        try { webViewUserAgent = contentView.getSettings().getUserAgentString(); } catch (Exception ignored) { }
        setupSplashWebView();
        splashView.loadUrl("file:///android_asset/www/index.html");
    }

    private WebView createWebView() {
        WebView w = new WebView(this);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setSupportZoom(false);
        s.setLoadsImagesAutomatically(true);
        s.setBlockNetworkImage(false);
        s.setBlockNetworkLoads(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        if (Build.VERSION.SDK_INT >= 21) {
            s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
            CookieManager.getInstance().setAcceptThirdPartyCookies(w, true);
        }
        return w;
    }

    private void setupSplashWebView() {
        splashView.addJavascriptInterface(new NativeBridge(), "MovixNative");
        splashView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                if (splashReady) return;
                splashReady = true;
                getConfiguredUrl(new UrlCallback() {
                    @Override public void onUrl(String url) { startLoad(url); }
                });
            }
        });
    }

    private void setupContentWebView() {
        contentView.setVisibility(View.INVISIBLE);
        contentView.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view, int newProgress) {
                if (!loading) return;
                int p = Math.max(5, Math.min(96, newProgress));
                String text = newProgress < 25 ? "Connexion au serveur…" : "Chargement de Movix…";
                updateSplashProgress(p, text);
            }
            @Override public boolean onConsoleMessage(ConsoleMessage message) { return true; }
        });

        contentView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url == null) return false;
                if (url.startsWith("http://") || url.startsWith("https://")) return false;
                openExternalUrl(url);
                return true;
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                if (request == null || request.getUrl() == null) return false;
                String url = request.getUrl().toString();
                if (url.startsWith("http://") || url.startsWith("https://")) return false;
                openExternalUrl(url);
                return true;
            }
            @Override public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                if (loading) updateSplashProgress(Math.max(5, view.getProgress()), "Connexion au serveur…");
            }
            @Override public void onPageFinished(WebView view, String url) {
                if (!loading) return;
                lastLoadedUrl = url == null ? lastLoadedUrl : url;
                showContent();
            }
            @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (Build.VERSION.SDK_INT >= 21 && request != null && request.isForMainFrame() && loading) finishWithError("server");
            }
            @Override public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                if (!loading) return;
                String current = view == null ? null : view.getUrl();
                if (failingUrl == null || current == null || failingUrl.equals(current)) finishWithError("server");
            }
            @Override public void onReceivedHttpError(WebView view, WebResourceRequest request, WebResourceResponse response) {
                if (Build.VERSION.SDK_INT >= 21 && request != null && request.isForMainFrame() && loading) {
                    int code = response == null ? 0 : response.getStatusCode();
                    if (code >= 400) finishWithError("server");
                }
            }
            @Override public void onReceivedSslError(WebView view, SslErrorHandler sslHandler, SslError error) {
                sslHandler.cancel();
                if (loading) finishWithError("ssl");
            }
        });
    }

    private void openExternalUrl(String url) {
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch (Exception ignored) { }
    }

    private boolean hasInternet() {
        ConnectivityManager cm = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo ni = cm.getActiveNetworkInfo();
        return ni != null && ni.isConnected();
    }

    private void getConfiguredUrl(final UrlCallback callback) {
        try {
            String js = "window.movixApp&&window.movixApp.getUrl?window.movixApp.getUrl():''";
            splashView.evaluateJavascript(js, new ValueCallback<String>() {
                @Override public void onReceiveValue(String value) {
                    String clean = decodeJsString(value);
                    if (clean.length() == 0) clean = DEFAULT_URL;
                    callback.onUrl(clean);
                }
            });
        } catch (Exception e) { callback.onUrl(DEFAULT_URL); }
    }

    private String decodeJsString(String value) {
        String clean = value == null ? "" : value;
        if (clean.startsWith("\"") && clean.endsWith("\"")) clean = clean.substring(1, clean.length()-1);
        return clean.replace("\\u0022", "\"").replace("\\/", "/").replace("\\\\", "\\");
    }

    private void updateSplashProgress(final int value, final String text) {
        if (splashView == null) return;
        splashView.post(new Runnable() { @Override public void run() {
            String safe = text.replace("\\", "\\\\").replace("'", "\\'");
            String js = "window.movixApp&&window.movixApp.setProgress(" + value + ", '" + safe + "')";
            if (Build.VERSION.SDK_INT >= 19) splashView.evaluateJavascript(js, null); else splashView.loadUrl("javascript:" + js);
        }});
    }

    private void showSplashError(final String type) {
        loading = false;
        currentScreen = SCREEN_ERROR;
        diagnosticMode = false;
        splashView.setVisibility(View.VISIBLE);
        contentView.setVisibility(View.INVISIBLE);
        splashView.post(new Runnable() { @Override public void run() {
            String js = "window.movixApp&&window.movixApp.showError('" + type + "')";
            if (Build.VERSION.SDK_INT >= 19) splashView.evaluateJavascript(js, null); else splashView.loadUrl("javascript:" + js);
        }});
    }

    private void finishWithError(String type) {
        if (!loading) return;
        loading = false;
        handler.removeCallbacks(timeoutRunnable);
        showSplashError(type);
    }

    private void resetForRetry() {
        loading = false;
        diagnosticMode = false;
        handler.removeCallbacksAndMessages(null);
        currentScreen = SCREEN_LOADING;
        loadGeneration++;
        try {
            if (contentView != null) {
                contentView.stopLoading();
                contentView.setVisibility(View.INVISIBLE);
            }
        } catch (Exception ignored) { }
        updateSplashProgress(0, "Vérification de la connexion…");
    }

    private void startLoad(final String url) {
        if (url == null || !(url.startsWith("http://") || url.startsWith("https://"))) {
            showSplashError("badurl");
            return;
        }
        resetForRetry();
        splashView.setVisibility(View.VISIBLE);
        contentView.setVisibility(View.INVISIBLE);
        lastLoadedUrl = url;
        if (!hasInternet()) {
            updateSplashProgress(0, "Aucune connexion Internet");
            handler.postDelayed(new Runnable() { @Override public void run() { if (!loading) showSplashError("offline"); } }, 350);
            return;
        }
        attempt++;
        loading = true;
        final long generation = loadGeneration;
        updateSplashProgress(5, "Connexion au serveur…");
        handler.postDelayed(new Runnable() { @Override public void run() {
            if (loading && generation == loadGeneration) finishWithError("slow");
        }}, 20000);
        try {
            contentView.loadUrl(url);
        } catch (Exception e) {
            if (generation == loadGeneration) finishWithError("server");
        }
    }

    private void retryLoad() {
        if (currentScreen != SCREEN_ERROR && currentScreen != SCREEN_LOADING) return;
        String url = lastLoadedUrl;
        if (url == null || url.length() == 0) url = DEFAULT_URL;
        startLoad(url);
    }

    private void openDiagnosticPage() {
        diagnosticMode = true;
        loading = false;
        handler.removeCallbacksAndMessages(null);
        currentScreen = SCREEN_ERROR;
        splashView.setVisibility(View.VISIBLE);
        contentView.setVisibility(View.INVISIBLE);
        final String url = (lastLoadedUrl == null || lastLoadedUrl.length() == 0) ? DEFAULT_URL : lastLoadedUrl;
        splashView.post(new Runnable() { @Override public void run() {
            String js = "window.movixApp&&window.movixApp.openDiagnostic&&window.movixApp.openDiagnostic()";
            if (Build.VERSION.SDK_INT >= 19) splashView.evaluateJavascript(js, null); else splashView.loadUrl("javascript:" + js);
        }});
        final String ua = webViewUserAgent;
        runDetailedDiagnostic(url, ua);
    }

    private void runDetailedDiagnostic(final String target, final String userAgent) {
        new Thread(new Runnable() { @Override public void run() {
            final String report = buildDiagnosticReport(target, userAgent);
            runOnUiThread(new Runnable() { @Override public void run() {
                if (splashView == null) return;
                String safe = report.replace("\\", "\\\\").replace("'", "\\'").replace("\n", "\\n").replace("\r", "");
                String js = "window.movixApp&&window.movixApp.setDiagnosticResult&&window.movixApp.setDiagnosticResult('" + safe + "')";
                if (Build.VERSION.SDK_INT >= 19) splashView.evaluateJavascript(js, null); else splashView.loadUrl("javascript:" + js);
            }});
        }}).start();
    }

    private String getInstalledWebViewInfo() {
        String[] packages = new String[]{"com.google.android.webview", "com.android.webview", "com.google.android.webview.beta", "com.google.android.webview.dev", "com.google.android.webview.canary"};
        android.content.pm.PackageManager pm = getPackageManager();
        for (String pkg : packages) {
            try {
                android.content.pm.PackageInfo pi = pm.getPackageInfo(pkg, 0);
                return pi.packageName + " " + (pi.versionName == null ? "version inconnue" : pi.versionName) + " (code " + pi.versionCode + ")";
            } catch (Exception ignored) { }
        }
        return "Composant WebView non identifié par nom de paquet";
    }

    private String buildDiagnosticReport(String target, String userAgent) {
        StringBuilder r = new StringBuilder();
        r.append("DIAGNOSTIC MOVIX\n");
        r.append("====================\n\n");
        r.append("1. APPLICATION\n");
        r.append("• Version : 1.8\n");
        r.append("• Android : ").append(Build.VERSION.RELEASE).append(" (API ").append(Build.VERSION.SDK_INT).append(")\n");
        r.append("• Appareil : ").append(Build.MANUFACTURER).append(" ").append(Build.MODEL).append("\n");
        r.append("• WebView : ").append(getInstalledWebViewInfo()).append("\n");
        r.append("• User-Agent Chromium : ").append(userAgent == null || userAgent.length() == 0 ? "inconnu" : userAgent).append("\n\n");

        r.append("2. RÉSEAU LOCAL\n");
        boolean internet = hasInternet();
        r.append(internet ? "✓ Connexion réseau détectée.\n" : "✗ Aucune connexion réseau détectée.\n");
        if (!internet) {
            r.append("Conclusion provisoire : le problème est probablement local (Wi‑Fi/données mobiles).\n");
            return r.toString();
        }
        r.append("✓ Le système Android signale une connexion active.\n\n");

        r.append("3. ADRESSE TESTÉE\n");
        r.append("• URL : ").append(target).append("\n");
        try {
            URL parsed = new URL(target);
            r.append("✓ Adresse HTTP(S) valide.\n");
            r.append("• Protocole : ").append(parsed.getProtocol().toUpperCase(Locale.US)).append("\n");
            r.append("• Hôte : ").append(parsed.getHost()).append("\n\n");
        } catch (Exception e) {
            r.append("✗ Adresse invalide : ").append(e.getClass().getSimpleName()).append(".\n");
            r.append("Conclusion : corrigez l'adresse dans le bouton URL.\n");
            return r.toString();
        }

        r.append("4. DNS\n");
        try {
            long t=System.currentTimeMillis();
            InetAddress[] addresses=InetAddress.getAllByName(new URL(target).getHost());
            long ms=System.currentTimeMillis()-t;
            r.append("✓ Résolution DNS réussie en ").append(ms).append(" ms.\n");
            for (InetAddress a: addresses) r.append("• ").append(a.getHostAddress()).append("\n");
        } catch (Exception e) {
            r.append("✗ Échec DNS : ").append(e.getClass().getSimpleName()).append(" — ").append(safeMessage(e)).append("\n");
            r.append("Conclusion : le nom de domaine ne peut pas être résolu depuis cet appareil/réseau.\n");
            return r.toString();
        }
        r.append("\n5. SERVEUR HTTPS/HTTP\n");
        HttpURLConnection c=null;
        try {
            long t=System.currentTimeMillis();
            c=(HttpURLConnection)new URL(target).openConnection();
            c.setConnectTimeout(8000);
            c.setReadTimeout(10000);
            c.setInstanceFollowRedirects(true);
            c.setRequestMethod("GET");
            c.setRequestProperty("User-Agent", "MovixAndroid5-Diagnostic/1.8");
            c.setRequestProperty("Range", "bytes=0-0");
            c.connect();
            int code=c.getResponseCode();
            long ms=System.currentTimeMillis()-t;
            r.append("✓ Réponse reçue en ").append(ms).append(" ms.\n");
            r.append("• Code HTTP : ").append(code).append(" ").append(c.getResponseMessage()).append("\n");
            r.append("• URL finale : ").append(c.getURL()).append("\n");
            if (code>=200 && code<400) r.append("✓ Le serveur répond correctement au niveau HTTP.\n");
            else r.append("✗ Le serveur renvoie un code HTTP d'erreur ou de redirection non finalisée.\n");
        } catch (Exception e) {
            r.append("✗ Échec de la connexion serveur : ").append(e.getClass().getSimpleName()).append(" — ").append(safeMessage(e)).append("\n");
            if (e instanceof javax.net.ssl.SSLException) r.append("• Cause probable : négociation TLS/certificat incompatible avec cet Android.\n");
            else if (e instanceof java.net.SocketTimeoutException) r.append("• Cause probable : serveur trop lent ou connexion bloquée.\n");
        } finally { if (c!=null) c.disconnect(); }
        r.append("\n6. ANALYSE WEBVIEW\n");
        r.append("• Le WebView de l'application utilise le moteur fourni/actualisé par Android.\n");
        r.append("• Le diagnostic réseau ci-dessus teste le serveur indépendamment de l'affichage WebView.\n");
        r.append("• Si HTTP/DNS sont OK mais que l'application reste blanche ou échoue, le problème est très probablement lié au moteur WebView/à la compatibilité JavaScript du système.\n\n");

        r.append("7. CONCLUSION\n");
        if (internet) {
            r.append("Le réseau local est disponible. ");
            r.append("Si la réponse HTTP est OK mais que Movix ne s'affiche pas dans l'application, le serveur est accessible et l'échec se situe probablement dans le WebView Android 5 ou dans une technologie Web moderne utilisée par le site.\n");
            r.append("Si le serveur renvoie une erreur, le problème est côté serveur/adresse/réseau.\n");
        }
        r.append("\nCe rapport est un diagnostic technique : il n'essaie pas de contourner un blocage réseau, un certificat invalide ou une restriction du serveur.");
        return r.toString();
    }

    private String safeMessage(Exception e) {
        String m=e.getMessage(); return m==null || m.length()==0 ? "aucun détail" : m.replace('\n',' ').replace('\r',' ');
    }

    private void showContent() {
        if (!loading) return;
        loading = false;
        currentScreen = SCREEN_CONTENT;
        handler.removeCallbacks(timeoutRunnable);
        updateSplashProgress(100, "Chargement terminé");
        contentView.setVisibility(View.VISIBLE);
        splashView.setVisibility(View.GONE);
    }

    private interface UrlCallback { void onUrl(String url); }

    public class NativeBridge {
        @android.webkit.JavascriptInterface public void retryLoad() { runOnUiThread(new Runnable() { @Override public void run() { retryLoad(); }}); }
        @android.webkit.JavascriptInterface public void startLoad(final String url) { runOnUiThread(new Runnable() { @Override public void run() { startLoad(url); }}); }
        @android.webkit.JavascriptInterface public void openDiagnostic() { runOnUiThread(new Runnable() { @Override public void run() { openDiagnosticPage(); }}); }
        @android.webkit.JavascriptInterface public void screenChanged(final String screen) { runOnUiThread(new Runnable() { @Override public void run() {
            if ("settings".equals(screen)) currentScreen=SCREEN_SETTINGS;
            else if ("error".equals(screen)) currentScreen=SCREEN_ERROR;
            else if ("loading".equals(screen)) currentScreen=SCREEN_LOADING;
            else if ("content".equals(screen)) currentScreen=SCREEN_CONTENT;
        }}); }
        @android.webkit.JavascriptInterface public void networkLost() { runOnUiThread(new Runnable() { @Override public void run() { if (loading) finishWithError("offline"); }}); }
    }

    @Override public void onBackPressed() {
        if (currentScreen == SCREEN_SETTINGS) { splashView.evaluateJavascript("window.movixApp&&window.movixApp.closeSettings&&window.movixApp.closeSettings()", null); return; }
        if (diagnosticMode) { diagnosticMode=false; showSplashError("server"); return; }
        if (currentScreen == SCREEN_ERROR) { splashView.evaluateJavascript("window.movixApp&&window.movixApp.goBack&&window.movixApp.goBack()", null); return; }
        if (currentScreen == SCREEN_LOADING) return;
        if (contentView != null && contentView.canGoBack()) contentView.goBack(); else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        loading=false;
        handler.removeCallbacks(timeoutRunnable);
        try { if (splashView != null) splashView.destroy(); } catch (Exception ignored) { }
        try { if (contentView != null) contentView.destroy(); } catch (Exception ignored) { }
        super.onDestroy();
    }
}
