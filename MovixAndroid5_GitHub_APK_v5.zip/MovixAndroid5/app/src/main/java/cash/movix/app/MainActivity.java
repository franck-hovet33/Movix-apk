package cash.movix.app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.Window;
import android.webkit.ConsoleMessage;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.SslErrorHandler;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.net.http.SslError;
import android.widget.FrameLayout;

import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends Activity {
    private WebView splashView;
    private WebView contentView;
    private FrameLayout root;
    private final Handler handler = new Handler();
    private final int RED = Color.rgb(217, 70, 70);

    private boolean loading = false;
    private boolean initialLoadStarted = false;
    private boolean blankCheckDone = false;
    private boolean softwareRetryDone = false;
    private int lastProgress = 0;
    private int attempt = 0;
    private PreflightTask activePreflight;

    private final Runnable timeoutRunnable = new Runnable() {
        @Override public void run() {
            if (loading) finishWithError("slow");
        }
    };

    private final Runnable blankCheckRunnable = new Runnable() {
        @Override public void run() {
            if (!loading || blankCheckDone) return;
            blankCheckDone = true;
            checkPageIsVisible();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setStatusBarColor(RED);
        getWindow().setNavigationBarColor(Color.BLACK);

        root = new FrameLayout(this);
        contentView = createWebView();
        splashView = createWebView();

        root.addView(contentView, new FrameLayout.LayoutParams(-1, -1));
        root.addView(splashView, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);

        setupContentWebView();
        setupSplashWebView();
        splashView.loadUrl("file:///android_asset/www/index.html");
    }

    private WebView createWebView() {
        WebView w = new WebView(this);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setSupportZoom(false);
        s.setLoadsImagesAutomatically(true);
        s.setBlockNetworkImage(false);
        s.setBlockNetworkLoads(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setUserAgentString("Mozilla/5.0 (Linux; Android 5.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Mobile Safari/537.36");
        if (Build.VERSION.SDK_INT >= 21) {
            s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
            CookieManager.getInstance().setAcceptThirdPartyCookies(w, true);
        }
        if (Build.VERSION.SDK_INT == 21 || Build.VERSION.SDK_INT == 22) {
            w.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        }
        return w;
    }

    private void setupSplashWebView() {
        splashView.addJavascriptInterface(new NativeBridge(), "MovixNative");
        splashView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                if (!initialLoadStarted) {
                    initialLoadStarted = true;
                    splashView.evaluateJavascript(
                        "(window.movixApp&&window.movixApp.getUrl)?window.movixApp.getUrl():''",
                        new android.webkit.ValueCallback<String>() {
                            @Override public void onReceiveValue(String value) {
                                String clean = value == null ? "" : value;
                                if (clean.startsWith("\"") && clean.endsWith("\"")) {
                                    clean = clean.substring(1, clean.length() - 1);
                                }
                                clean = clean.replace("\\u0022", "\"").replace("\\/", "/");
                                if (clean.length() == 0) clean = "https://movix.cash";
                                startLoad(clean);
                            }
                        });
                }
            }
        });
        splashView.setWebChromeClient(new WebChromeClient());
    }

    private void setupContentWebView() {
        contentView.setVisibility(View.INVISIBLE);
        contentView.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view, int newProgress) {
                lastProgress = newProgress;
                if (loading) {
                    int p = Math.max(8, Math.min(96, newProgress));
                    updateSplashProgress(p, newProgress < 30 ? "Connexion au serveur…" : "Chargement de Movix…");
                }
            }
            @Override public boolean onConsoleMessage(ConsoleMessage consoleMessage) {
                return true;
            }
        });
        contentView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url == null) return false;
                if (url.startsWith("http://") || url.startsWith("https://")) {
                    return false;
                }
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                } catch (Exception ignored) {}
                return true;
            }

            @Override public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                if (loading) updateSplashProgress(Math.max(8, lastProgress), "Connexion au serveur…");
            }

            @Override public void onPageFinished(WebView view, String url) {
                if (!loading) return;
                handler.removeCallbacks(blankCheckRunnable);
                handler.postDelayed(blankCheckRunnable, 1600);
            }

            @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (Build.VERSION.SDK_INT >= 21 && request != null && request.isForMainFrame() && loading) {
                    finishWithError("server");
                }
            }

            @Override public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                if (loading) finishWithError("server");
            }

            @Override public void onReceivedHttpError(WebView view, WebResourceRequest request, WebResourceResponse errorResponse) {
                if (Build.VERSION.SDK_INT >= 21 && request != null && request.isForMainFrame() && loading) {
                    int code = errorResponse == null ? 0 : errorResponse.getStatusCode();
                    if (code >= 400) finishWithError("server");
                }
            }

            @Override public void onReceivedSslError(WebView view, SslErrorHandler sslHandler, SslError error) {
                sslHandler.cancel();
                if (loading) finishWithError("ssl");
            }
        });
    }

    private boolean hasInternet() {
        ConnectivityManager cm = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo ni = cm.getActiveNetworkInfo();
        return ni != null && ni.isConnected();
    }

    private void updateSplashProgress(final int value, final String text) {
        if (splashView == null) return;
        splashView.post(new Runnable() {
            @Override public void run() {
                String safe = text.replace("\\", "\\\\").replace("'", "\\'");
                String js = "window.movixApp&&window.movixApp.setProgress(" + value + ", '" + safe + "')";
                if (Build.VERSION.SDK_INT >= 19) splashView.evaluateJavascript(js, null);
                else splashView.loadUrl("javascript:" + js);
            }
        });
    }

    private void showSplashError(final String type) {
        splashView.setVisibility(View.VISIBLE);
        contentView.setVisibility(View.INVISIBLE);
        splashView.post(new Runnable() {
            @Override public void run() {
                String js = "window.movixApp&&window.movixApp.showError('" + type + "')";
                if (Build.VERSION.SDK_INT >= 19) splashView.evaluateJavascript(js, null);
                else splashView.loadUrl("javascript:" + js);
            }
        });
    }

    private void finishWithError(String type) {
        loading = false;
        handler.removeCallbacks(timeoutRunnable);
        handler.removeCallbacks(blankCheckRunnable);
        if (activePreflight != null) {
            activePreflight.cancel(true);
            activePreflight = null;
        }
        showSplashError(type);
    }

    private void prepareNewAttempt() {
        attempt++;
        loading = false;
        blankCheckDone = false;
        softwareRetryDone = false;
        lastProgress = 0;
        handler.removeCallbacks(timeoutRunnable);
        handler.removeCallbacks(blankCheckRunnable);
        if (activePreflight != null) {
            activePreflight.cancel(true);
            activePreflight = null;
        }
        try {
            contentView.stopLoading();
            contentView.loadUrl("about:blank");
            contentView.clearHistory();
            contentView.clearCache(false);
        } catch (Exception ignored) {}
        contentView.setVisibility(View.INVISIBLE);
        splashView.setVisibility(View.VISIBLE);
        updateSplashProgress(0, "Vérification de la connexion…");
    }

    private void startLoad(final String url) {
        if (url == null || !(url.startsWith("http://") || url.startsWith("https://"))) {
            showSplashError("badurl");
            return;
        }
        if (!hasInternet()) {
            showSplashError("offline");
            return;
        }
        prepareNewAttempt();
        loading = true;
        final int thisAttempt = attempt;
        updateSplashProgress(5, "Vérification de la connexion…");
        handler.postDelayed(timeoutRunnable, 15000);
        contentView.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        contentView.loadUrl(url);
        // A lightweight network preflight is deliberately used only as a backup signal.
        // The WebView itself performs the real page load, avoiding TLS differences between stacks.
        activePreflight = new PreflightTask(thisAttempt);
        activePreflight.execute(url);
    }

    private void retryLoad() {
        String url = "https://movix.cash";
        try {
            final String js = "window.movixApp&&window.movixApp.getUrl?window.movixApp.getUrl():''";
            splashView.evaluateJavascript(js, new android.webkit.ValueCallback<String>() {
                @Override public void onReceiveValue(String value) {
                    String clean = value == null ? "" : value;
                    if (clean.startsWith("\"") && clean.endsWith("\"")) clean = clean.substring(1, clean.length()-1);
                    clean = clean.replace("\\u0022", "\"").replace("\\/", "/");
                    if (clean.length() == 0) clean = "https://movix.cash";
                    startLoad(clean);
                }
            });
        } catch (Exception e) {
            startLoad(url);
        }
    }

    private class PreflightTask extends AsyncTask<String, Void, Boolean> {
        private final int taskAttempt;
        private String target;
        PreflightTask(int a) { taskAttempt = a; }
        @Override protected Boolean doInBackground(String... urls) {
            target = urls[0];
            HttpURLConnection c = null;
            try {
                URL u = new URL(target);
                c = (HttpURLConnection)u.openConnection();
                c.setConnectTimeout(3500);
                c.setReadTimeout(3500);
                c.setInstanceFollowRedirects(true);
                c.setRequestMethod("GET");
                c.setRequestProperty("Range", "bytes=0-0");
                c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 5.0) AppleWebKit/537.36 Chrome/80 Mobile Safari/537.36");
                int code = c.getResponseCode();
                return code >= 200 && code < 500;
            } catch (Exception e) {
                return false;
            } finally {
                if (c != null) c.disconnect();
            }
        }
        @Override protected void onPostExecute(Boolean ok) {
            if (taskAttempt != attempt || !loading) return;
            activePreflight = null;
            if (!ok && !hasInternet()) {
                finishWithError("offline");
            } else if (!ok) {
                // Do not abort the WebView immediately: some servers reject the lightweight
                // preflight while accepting the real browser request.
                updateSplashProgress(Math.max(8, lastProgress), "Connexion au serveur…");
            } else {
                updateSplashProgress(Math.max(12, lastProgress), "Connexion établie…");
            }
        }
    }

    private void checkPageIsVisible() {
        if (!loading) return;
        try {
            contentView.evaluateJavascript(
                "(function(){var b=document.body;var d=document.documentElement;var t=b?((b.innerText||'').trim()):'';var h=d?d.innerHTML.length:0;var c=b?b.children.length:0;return JSON.stringify({text:t.length,html:h,children:c,title:document.title||''});})()",
                new android.webkit.ValueCallback<String>() {
                    @Override public void onReceiveValue(String value) {
                        if (!loading) return;
                        boolean empty = value == null || value.equals("null") || value.contains("\"html\":0") || value.contains("\"children\":0") || (value.contains("\"text\":0") && !value.matches(".*\"html\":([2-9][0-9]{3,}|[1-9][0-9]{4,}).*"));
                        if (empty && !softwareRetryDone && (Build.VERSION.SDK_INT == 21 || Build.VERSION.SDK_INT == 22)) {
                            softwareRetryDone = true;
                            contentView.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
                            updateSplashProgress(18, "Optimisation de l'affichage…");
                            contentView.reload();
                            handler.postDelayed(new Runnable() {
                                @Override public void run() { if (loading) checkPageIsVisible(); }
                            }, 3000);
                            return;
                        }
                        if (empty) {
                            finishWithError("compat");
                            return;
                        }
                        loading = false;
                        handler.removeCallbacks(timeoutRunnable);
                        updateSplashProgress(100, "Chargement terminé");
                        handler.postDelayed(new Runnable() {
                            @Override public void run() {
                                contentView.setVisibility(View.VISIBLE);
                                splashView.setVisibility(View.GONE);
                            }
                        }, 250);
                    }
                });
        } catch (Exception e) {
            finishWithError("compat");
        }
    }

    public class NativeBridge {
        @JavascriptInterface
        public void startLoad(final String url) {
            runOnUiThread(new Runnable() {
                @Override public void run() { startLoad(url); }
            });
        }

        @JavascriptInterface
        public void retryLoad() {
            runOnUiThread(new Runnable() {
                @Override public void run() { retryLoad(); }
            });
        }

        @JavascriptInterface
        public void networkLost() {
            runOnUiThread(new Runnable() {
                @Override public void run() { finishWithError("offline"); }
            });
        }

        @JavascriptInterface
        public void testUrl(final String url) {
            if (url == null || !(url.startsWith("http://") || url.startsWith("https://"))) {
                splashView.post(new Runnable() { @Override public void run() { splashView.evaluateJavascript("window.movixApp&&window.movixApp.testResult(false)", null); } });
                return;
            }
            new PreflightTask(attempt) {
                @Override protected void onPostExecute(Boolean ok) {
                    splashView.post(new Runnable() {
                        @Override public void run() {
                            String js = "window.movixApp&&window.movixApp.testResult(" + ok + ")";
                            if (Build.VERSION.SDK_INT >= 19) splashView.evaluateJavascript(js, null);
                            else splashView.loadUrl("javascript:" + js);
                        }
                    });
                }
            }.execute(url);
        }
    }

    @Override public void onBackPressed() {
        if (splashView.getVisibility() == View.VISIBLE) {
            splashView.evaluateJavascript("window.movixApp&&window.movixApp.goBack&&window.movixApp.goBack()", null);
            return;
        }
        if (contentView.canGoBack()) contentView.goBack(); else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        loading = false;
        handler.removeCallbacks(timeoutRunnable);
        handler.removeCallbacks(blankCheckRunnable);
        if (activePreflight != null) activePreflight.cancel(true);
        if (splashView != null) splashView.destroy();
        if (contentView != null) contentView.destroy();
        super.onDestroy();
    }
}
