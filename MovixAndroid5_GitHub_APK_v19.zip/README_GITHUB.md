# Compilation GitHub — Movix Android 5 v18

1. Envoyer le contenu du dossier dans le dépôt GitHub.
2. Ouvrir **Actions**.
3. Choisir **Build Movix APK**.
4. Cliquer sur **Run workflow**.
5. Une fois terminé, ouvrir l'artifact **movix-android5-v18** et récupérer l'APK.

La version v18 est 2.4 (versionCode 15).
