package cash.movix.app;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Handler;
import android.view.Window;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

public class MainActivity extends Activity {
    private WebView splashView;
    private WebView contentView;
    private FrameLayout root;
    private final Handler handler = new Handler();
    private boolean loading = false;
    private final int RED = Color.rgb(217, 70, 70);

    private final Runnable timeoutRunnable = new Runnable() {
        @Override public void run() {
            if (loading) {
                loading = false;
                showSplashError("slow");
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);

        getWindow().setStatusBarColor(RED);
        getWindow().setNavigationBarColor(Color.BLACK);

        root = new FrameLayout(this);

        contentView = createWebView();
        splashView = createWebView();

        // Content is behind the splash. It loads Movix while the splash remains visible.
        root.addView(contentView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));
        root.addView(splashView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));

        setContentView(root);

        setupContentWebView();
        setupSplashWebView();

        splashView.loadUrl("file:///android_asset/www/index.html");
    }

    private WebView createWebView() {
        WebView w = new WebView(this);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setSupportZoom(false);
        s.setLoadsImagesAutomatically(true);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setUserAgentString(s.getUserAgentString() + " MovixAndroid5/1.0");
        return w;
    }

    private void setupSplashWebView() {
        splashView.addJavascriptInterface(new NativeBridge(), "MovixNative");
        splashView.setWebViewClient(new WebViewClient());
        splashView.setWebChromeClient(new WebChromeClient());
    }

    private void setupContentWebView() {
        contentView.setVisibility(View.INVISIBLE);

        contentView.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view, int newProgress) {
                updateSplashProgress(newProgress);
            }
        });

        contentView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                view.loadUrl(url);
                return true;
            }

            @Override public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                updateSplashProgress(5);
            }

            @Override public void onPageFinished(WebView view, String url) {
                if (loading) {
                    loading = false;
                    handler.removeCallbacks(timeoutRunnable);
                    updateSplashProgress(100);
                    handler.postDelayed(new Runnable() {
                        @Override public void run() {
                            contentView.setVisibility(View.VISIBLE);
                            splashView.setVisibility(View.GONE);
                        }
                    }, 150);
                }
            }

            @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame() && loading) {
                    loading = false;
                    handler.removeCallbacks(timeoutRunnable);
                    showSplashError("server");
                }
            }

            @Override public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                if (loading) {
                    loading = false;
                    handler.removeCallbacks(timeoutRunnable);
                    showSplashError("server");
                }
            }
        });
    }

    private boolean hasInternet() {
        ConnectivityManager cm =
                (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo ni = cm.getActiveNetworkInfo();
        return ni != null && ni.isConnected();
    }

    private void updateSplashProgress(final int value) {
        splashView.post(new Runnable() {
            @Override public void run() {
                splashView.loadUrl("javascript:window.movixApp && window.movixApp.setProgress(" +
                        value + ", 'Chargement de Movix…')");
            }
        });
    }

    private void showSplashError(final String type) {
        splashView.setVisibility(View.VISIBLE);
        contentView.setVisibility(View.INVISIBLE);
        splashView.post(new Runnable() {
            @Override public void run() {
                splashView.loadUrl("javascript:window.movixApp && window.movixApp.showError('" +
                        type + "')");
            }
        });
    }

    private void startLoad(final String url) {
        if (!hasInternet()) {
            showSplashError("offline");
            return;
        }
        loading = true;
        splashView.setVisibility(View.VISIBLE);
        contentView.setVisibility(View.INVISIBLE);
        updateSplashProgress(8);
        handler.removeCallbacks(timeoutRunnable);
        handler.postDelayed(timeoutRunnable, 15000);
        contentView.loadUrl(url);
    }

    public class NativeBridge {
        @JavascriptInterface
        public void startLoad(final String url) {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    startLoad(url);
                }
            });
        }
    }

    @Override public void onBackPressed() {
        if (splashView.getVisibility() == View.VISIBLE) {
            splashView.evaluateJavascript(
                    "window.movixApp && window.movixApp.closeSettings && window.movixApp.closeSettings()",
                    null);
            return;
        }
        if (contentView.canGoBack()) {
            contentView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override protected void onDestroy() {
        handler.removeCallbacks(timeoutRunnable);
        if (splashView != null) splashView.destroy();
        if (contentView != null) contentView.destroy();
        super.onDestroy();
    }
}
