(function(){
  var DEFAULT_URL = "https://movix.cash";
  var url = localStorage.getItem("movix_url") || DEFAULT_URL;
  var splash = document.getElementById("splash");
  var settings = document.getElementById("settings");
  var error = document.getElementById("error");
  var percent = document.getElementById("percent");
  var progress = document.getElementById("progress");
  var status = document.getElementById("status");
  var urlInput = document.getElementById("urlInput");
  var urlMessage = document.getElementById("urlMessage");

  urlInput.value = url;

  function show(el){el.classList.remove("hidden")}
  function hide(el){el.classList.add("hidden")}
  function setProgress(n, text){
    n = Math.max(0, Math.min(100, n|0));
    percent.textContent = n + " %";
    progress.style.width = n + "%";
    if(text) status.textContent = text;
  }
  function validUrl(value){
    return /^https?:\/\/[^\s]+$/i.test(value);
  }
  function openSettings(){
    urlInput.value = localStorage.getItem("movix_url") || DEFAULT_URL;
    urlMessage.textContent = "";
    hide(splash); hide(error); show(settings);
  }
  function closeSettings(){
    hide(settings); show(splash);
  }
  function showError(type){
    hide(splash); hide(settings); show(error);
    var title=document.getElementById("errorTitle");
    var text=document.getElementById("errorText");
    var advice=document.getElementById("errorAdvice");
    if(type==="offline"){
      title.textContent="Aucune connexion Internet";
      text.textContent="Le téléphone ne semble pas avoir accès à Internet.";
      advice.textContent="Vérifiez le Wi‑Fi ou les données mobiles, puis appuyez sur « Réessayer ». Si la connexion revient, Movix pourra être chargé.";
    } else if(type==="slow"){
      title.textContent="Connexion très lente";
      text.textContent="La connexion ou le serveur met trop de temps à répondre.";
      advice.textContent="Vérifiez votre réseau. Vous pouvez réessayer ou vérifier l'adresse du serveur dans les paramètres.";
    } else if(type==="badurl"){
      title.textContent="Adresse Movix incorrecte";
      text.textContent="L'adresse configurée n'est pas valide.";
      advice.textContent="Ouvrez les paramètres et vérifiez l'adresse du serveur. Elle doit commencer par http:// ou https://.";
    } else {
      title.textContent="Movix est inaccessible";
      text.textContent="Internet semble fonctionner, mais le serveur Movix ne répond pas correctement.";
      advice.textContent="Réessayez dans quelques instants. Si le problème continue, vérifiez l'adresse du serveur dans les paramètres.";
    }
  }

  document.getElementById("settingsBtn").onclick=openSettings;
  document.getElementById("backBtn").onclick=closeSettings;
  document.getElementById("errorSettingsBtn").onclick=openSettings;
  document.getElementById("retryBtn").onclick=function(){
    hide(error); show(splash); start();
  };
  document.getElementById("saveBtn").onclick=function(){
    var value=urlInput.value.trim().replace(/\\/+$/,"");
    if(!validUrl(value)){
      urlMessage.textContent="Adresse invalide. Exemple : https://movix.cash";
      return;
    }
    localStorage.setItem("movix_url",value);
    url=urlInput.value=value;
    urlMessage.textContent="Adresse enregistrée.";
    setTimeout(closeSettings,350);
    start();
  };
  document.getElementById("testBtn").onclick=function(){
    var value=urlInput.value.trim().replace(/\\/+$/,"");
    if(!validUrl(value)){urlMessage.textContent="Adresse invalide.";return}
    urlMessage.textContent="Test en cours…";
    var x=new XMLHttpRequest();
    x.open("GET",value,true);
    x.timeout=8000;
    x.onreadystatechange=function(){
      if(x.readyState===4){
        urlMessage.textContent=(x.status>=200&&x.status<500) ? "Serveur joignable." : "Le serveur ne répond pas correctement.";
      }
    };
    x.onerror=function(){urlMessage.textContent="Impossible de joindre cette adresse."};
    x.ontimeout=function(){urlMessage.textContent="Le test a expiré."};
    try{x.send()}catch(e){urlMessage.textContent="Adresse inaccessible."}
  };

  window.movixApp={
    setProgress:setProgress,
    showError:showError,
    getUrl:function(){return localStorage.getItem("movix_url")||DEFAULT_URL},
    closeSettings:closeSettings
  };

  function start(){
    url=localStorage.getItem("movix_url")||DEFAULT_URL;
    if(!navigator.onLine){showError("offline");return}
    setProgress(5,"Vérification de la connexion…");
    // The native Android wrapper performs the actual WebView load.
    if(window.MovixNative && window.MovixNative.startLoad){
      window.MovixNative.startLoad(url);
    } else {
      // Browser/HTML preview fallback.
      setProgress(20,"Connexion au serveur…");
      setTimeout(function(){
        setProgress(100,"Chargement terminé");
        window.location.href=url;
      },500);
    }
  }
  window.addEventListener("online",function(){ if(!settings.classList.contains("hidden"))return; start(); });
  window.addEventListener("offline",function(){ showError("offline"); });
  start();
})();