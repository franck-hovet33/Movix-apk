# Movix Android 5 — compilation automatique

Ce projet contient un workflow GitHub Actions dans `.github/workflows/build-apk.yml`.

Il compile automatiquement `app-debug.apk` avec Java 17, Android SDK 34 et Gradle 8.2.2.

## Compilation

1. Importer tout le contenu du projet dans un dépôt GitHub.
2. Ouvrir **Actions**.
3. Choisir **Build Movix APK**.
4. Cliquer sur **Run workflow** (ou pousser sur `main`/`master`).
5. Une fois terminé, ouvrir le run puis télécharger l'artifact **Movix-Android5-APK**.

Le fichier produit est :

`app-debug.apk`
