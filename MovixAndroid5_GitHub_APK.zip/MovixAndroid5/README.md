# Movix Android 5 — première version

Cette archive contient une première base d'application Android compatible avec Android 5.0 (API 21) et supérieur.

## Fonctionnement

- Icône Movix pour le bureau.
- Écran de démarrage basé sur le visuel fourni.
- Texte `*chargement*` et pourcentage réel de progression du WebView, affiché pendant que Movix se charge en arrière-plan.
- Bouton ⚙ sur l'écran de démarrage uniquement.
- Modification de l'URL Movix et sauvegarde locale.
- Détection de l'absence de connexion Internet.
- Page dédiée pour les erreurs courantes.
- Barre d'état Android en rouge Movix.
- WebView pour ouvrir l'adresse configurée.
- Bouton Retour Android qui respecte l'historique WebView.

## URL initiale

https://movix.cash

Elle peut être modifiée depuis ⚙.

## Important

Le projet est fourni comme **source prêt à importer dans Android Studio**. L'environnement de génération Android/Gradle n'est pas installé ici, donc je ne peux pas fournir un APK signé directement dans cette réponse.

## Construction

1. Ouvrir le dossier `MovixAndroid5` dans Android Studio.
2. Laisser Gradle télécharger les composants nécessaires.
3. Vérifier que le SDK Android demandé est installé.
4. Construire l'APK debug avec `Build > Build APK(s)`.

## Limitation volontaire de cette V1

Le WebView charge directement Movix. Le contenu de Movix reste donc dépendant de la compatibilité du site et du WebView présent sur l'ancien téléphone Android 5.
